let lis = document.querySelectorAll('.tab .tab-item')
let divs = document.querySelectorAll('.box .info')

for (let i = 0; i < lis.length; i++) {
    lis[i].addEventListener('click', function() {

        document.querySelector('.tab .active').classList.remove('active')

        this.classList.add('active')


        document.querySelector('.box .active').classList.remove('active')


        divs[i].classList.add('active')

    })
}